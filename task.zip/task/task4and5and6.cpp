#include <iostream>
#include <vector>

struct Vector
{
    int size;
    int elements;
    int *mem;
    Vector() : size(10), elements(0), mem(new int[size])
    {
    }
    Vector(int n)
    {
        if (elements == size)
        {
            int *newArray = new int[size * 2];
            for (int i = 0; i < size; i++)
            {
                newArray[i] = mem[i];
            }
            delete[] mem;
            mem = newArray;
            size = size * 2;
        }
// segmentation fault
        mem[elements++] = n;
    }

    // Vector &operator+(const Vector &newVector)
    // {
    //     for (int i = 0; i < size; i++)
    //     {
    //         return Vector(mem[i] + newVector.mem[i]);
    //     }
    // }
    // std::ostream &operator<<(std::ostream &o, const Vector &newVector)
    // {
    //     for (int i = 0; i < size; i++)
    //     {
    //         o << "<" << mem[i] << ", " << newVector.mem[i];
    //         return o;
    //     }
    // }
};

int main()
{
    for (int i = 0; i < 100; i++)
    {
        Vector v(i * i);
    }

    // Vector v1;
    // for (int i = 0; i < 100; i++)
    // {
    //     std::cout << v1.mem[i] << std::endl;
    // }

    // std::cout << v + v1 << std::endl;
    return 0;
}